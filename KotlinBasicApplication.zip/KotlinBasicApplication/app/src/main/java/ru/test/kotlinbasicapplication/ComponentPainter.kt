package ru.test.kotlinbasicapplication

import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView


// Класс который по входящему набору списка атрибутов, строит динамическую форму
class ComponentPainter (val activity: MainActivity,
                        val rootContainer: LinearLayout,
                        val attributeList: AttributeList) {
    // создаем текстовый редактор
    private val simpleLayoutParametrs =  LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT) ;

    private fun createTextEditor(attribute: Attribute){

//        val textView = TextView(activity)
//        textView.setText(attribute.name)
//        var relativeParameters = RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT)
//        relativeParameters.addRule(RelativeLayout.BELOW)
//        textView.setLayoutParams(relativeParameters)
//
//        rootContainer.addView(textView)

    }
    // добавляем редактор по умолчанию
    private fun createSimpleEditor(attribute: Attribute){
        val default = TextView(activity)
        default.setText(attribute.name)
        default.setLayoutParams(LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        rootContainer.addView(default)
    }
    // Создать атрибут
    private fun createEditor(attribute: Attribute){
        //создаем горизонтальную разметку
        val horizontalLayout = LinearLayout(activity)
        horizontalLayout.orientation = LinearLayout.HORIZONTAL
        // Создаем текст вью. Просмотр текста
        val textView = TextView(activity)
        textView.setText(attribute.name)
        textView.setRawInputType(1)

        textView.width = 300
        horizontalLayout.addView(textView)
        // создаем редактор текста
        val button = Button(activity)
        button.width = 600
        horizontalLayout.addView(button)

        val button2 = Button(activity)
        button2.width = 80
        horizontalLayout.addView(button2)
        
        rootContainer.addView(horizontalLayout)
    }

    // Нарисовать компоненты на Активити
    fun drawAttributes() {
        // Устанавливаем параметры
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT)
        // Перебираем атрибуты и добавляем элементы в список
        for (i in 0..attributeList.count()-1) {
            val attribute = attributeList.get(i)
            createEditor(attribute)
        }
    }

}